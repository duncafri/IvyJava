/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RecipeFinderApp extends Application {
    private ArrayList<Recipe> recipeList;  // List to hold all recipes
    private ArrayList<Ingredient> userIngredients;  // List to hold selected user ingredients

    private TextArea outputArea;  // Text area for output display

    // Constructor
    public RecipeFinderApp() {
        this.recipeList = new ArrayList<>();
        this.userIngredients = new ArrayList<>();
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Recipe Finder");

        // Create a VBox to hold everything
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));

        // Create a grid pane for ingredient buttons
        GridPane ingredientGrid = new GridPane();
        ingredientGrid.setPadding(new Insets(10));
        ingredientGrid.setVgap(8);
        ingredientGrid.setHgap(10);

        // Load ingredients and recipes from files
        ArrayList<Ingredient> ingredients = DataLoader.loadIngredients("FinalProject\\recipefinder\\src\\main\\java\\recipefinder\\ingredients.txt");
        recipeList = DataLoader.loadRecipes("FinalProject\\recipefinder\\src\\main\\java\\recipefinder\\recipes.txt"); // Load recipes into recipeList

        // Add buttons for each ingredient
        int columnCount = 0;
        int rowCount = 0;
        for (Ingredient ingredient : ingredients) {
            Button ingredientButton = new Button(ingredient.getIngredientName());
            ingredientButton.setOnAction(e -> addUserIngredient(ingredient));
            ingredientGrid.add(ingredientButton, columnCount, rowCount);

            // Update column and row count for wrapping
            columnCount++;
            if (columnCount >= 5) { // Start a new row after 5 buttons
                columnCount = 0;
                rowCount++;
            }
        }

        // Add the ingredient grid to the vbox
        vbox.getChildren().add(ingredientGrid);

        // Output area
        outputArea = new TextArea();
        outputArea.setEditable(false);
        vbox.getChildren().add(new Label("Output:"));
        vbox.getChildren().add(outputArea);

        // Add the main controls for finding recipes
        Button findRecipesButton = new Button("Find Matching Recipes");
        findRecipesButton.setOnAction(e -> findMatchingRecipes());
        vbox.getChildren().add(findRecipesButton);

        Button resetButton = new Button("Reset");
        resetButton.setOnAction(e -> reset());
        vbox.getChildren().add(resetButton);

        // Set the scene to fill the screen
        Scene scene = new Scene(vbox, 800, 600); // Set the initial size to fill the screen
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true); // Allow the window to be maximized
        primaryStage.show();
    }

    private void addUserIngredient(Ingredient ingredient) {
        userIngredients.add(ingredient);
        outputArea.appendText("Added ingredient: " + ingredient.getIngredientName() + "\n");
    }

    private void findMatchingRecipes() {
        ArrayList<Recipe> matchingRecipes = new ArrayList<>();
        
        // Check how many user ingredients are selected
        int selectedCount = userIngredients.size();
        
        for (Recipe recipe : recipeList) {
            int matchingCount = 0; // Counter for matched ingredients
            
            for (Ingredient required : recipe.getIngredients()) {
                for (Ingredient userIng : userIngredients) {
                    if (required.getIngredientName().equalsIgnoreCase(userIng.getIngredientName()) && userIng.isAvailable()) {
                        matchingCount++;
                        break; // Stop checking after finding a match
                    }
                }
            }

            // Add recipe if there's at least one match for one ingredient
            if (selectedCount == 1 && matchingCount >= 1) {
                matchingRecipes.add(recipe);
            } 
            // If multiple ingredients are selected, check for at least two matches
            else if (selectedCount > 1 && matchingCount >= 2) {
                matchingRecipes.add(recipe);
            }
        }

        // Display the results
        if (matchingRecipes.isEmpty()) {
            outputArea.appendText("No matching recipes found.\n");
        } else {
            outputArea.appendText("Matching Recipes:\n");
            for (Recipe recipe : matchingRecipes) {
                outputArea.appendText(recipe + "\n");
            }
        }
    }

    private void reset() {
        userIngredients.clear();
        outputArea.clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
