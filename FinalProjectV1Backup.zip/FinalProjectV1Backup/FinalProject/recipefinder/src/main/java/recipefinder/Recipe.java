/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/


package recipefinder;

import java.util.ArrayList;

public class Recipe {
    private String recipeName;
    private ArrayList<Ingredient> ingredients;
    private String[] steps;
    private int preparationTime;
    private boolean isFavorite;

    // Constructor
    public Recipe(String recipeName, ArrayList<Ingredient> ingredients, String[] steps, int preparationTime, boolean isFavorite) {
        this.recipeName = recipeName;
        this.ingredients = ingredients;
        this.steps = steps;
        this.preparationTime = preparationTime;
        this.isFavorite = isFavorite;
    }

    // Getters and setters
    public String getRecipeName() { return recipeName; }
    public void setRecipeName(String recipeName) { this.recipeName = recipeName; }

    public ArrayList<Ingredient> getIngredients() { return ingredients; }
    public void setIngredients(ArrayList<Ingredient> ingredients) { this.ingredients = ingredients; }

    public String[] getSteps() { return steps; }
    public void setSteps(String[] steps) { this.steps = steps; }

    public int getPreparationTime() { return preparationTime; }
    public void setPreparationTime(int preparationTime) { this.preparationTime = preparationTime; }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean isFavorite) { this.isFavorite = isFavorite; }

    // Match ingredients with user input
    public boolean matchesIngredients(ArrayList<Ingredient> userIngredients) {
        for (Ingredient required : ingredients) {
            boolean found = false;
            for (Ingredient userIng : userIngredients) {
                if (required.getIngredientName().equalsIgnoreCase(userIng.getIngredientName()) && userIng.isAvailable()) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return recipeName + " (Prep Time: " + preparationTime + " mins)";
    }
}