import java.util.ArrayList;

public class RecipeTest {
    public static void main(String[] args) {
        ArrayList<Ingredient> ingredients = new ArrayList<>();
        ingredients.add(new Ingredient("Tomato", "Vegetable", 2, "pieces"));
        ingredients.add(new Ingredient("Salt", "Spice", 1, "teaspoon"));

        String[] steps = {"Chop the tomatoes", "Add salt"};
        Recipe recipe = new Recipe("Tomato Salad", ingredients, steps, 10);

        System.out.println(recipe);
    }
}