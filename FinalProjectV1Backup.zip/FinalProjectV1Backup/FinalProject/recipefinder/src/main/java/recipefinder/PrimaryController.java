/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

import java.io.IOException;

import javafx.fxml.FXML;

public class PrimaryController {

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
