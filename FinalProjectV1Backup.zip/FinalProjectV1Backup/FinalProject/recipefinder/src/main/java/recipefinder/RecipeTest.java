/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

public class RecipeTest {

    @Test
    public void testRecipeCreation() {
        ArrayList<Ingredient> ingredients = new ArrayList<>();
        ingredients.add(new Ingredient("Tomato", "Vegetable", 2.0, "pieces", false));
        ingredients.add(new Ingredient("Salt", "Spice", 1.0, "teaspoon", false));

        String[] stepsArray = {"Cut the tomatoes.", "Add salt to the tomatoes."};

        Recipe recipe = new Recipe("Tomato Salad", ingredients, stepsArray, 10, false);

        assertEquals("Tomato Salad", recipe.getName());
        assertEquals(2, recipe.getIngredients().size());
        assertEquals(2, recipe.getSteps().length); // Assuming steps is an array
        assertEquals(10, recipe.getPreparationTime());
    }

    @Test
    public void testRecipeAddIngredient() {
        Recipe recipe = new Recipe("Empty Salad", new ArrayList<>(), new String[0], 5, false);

        recipe.addIngredient(new Ingredient("Lettuce", "Vegetable", 1.0, "bunch", false));

        assertEquals(1, recipe.getIngredients().size());
        assertEquals("Lettuce", recipe.getIngredients().get(0).getName());
    }

    @Test
    public void testRecipeAddStep() {
        Recipe recipe = new Recipe("No Step Salad", new ArrayList<>(), new String[0], 5, false);

        recipe.addStep("Mix everything together.");

        assertEquals(1, recipe.getSteps().length);
        assertEquals("Mix everything together.", recipe.getSteps()[0]);
    }
}
