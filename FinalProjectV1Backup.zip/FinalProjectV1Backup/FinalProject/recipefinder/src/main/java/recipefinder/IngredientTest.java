//* 
Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

public class IngredientTest {
    public static void main(String[] args) {
        // Create an Ingredient instance with the correct type for quantity
        Ingredient ingredient = new Ingredient("Tomato", "Vegetable", 2.0, "pieces", true);
        System.out.println(ingredient); // This will call the toString method of Ingredient

        // Update the quantity and print the updated value
        ingredient.setQuantity(3.0); // Ensure the method accepts a double
        System.out.println("Updated quantity: " + ingredient.getQuantity());
    }
}
