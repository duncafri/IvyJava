/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

public class Ingredient {
    private String ingredientName;
    private String ingredientType;
    private double quantity;
    private String unit;
    private boolean isAvailable;

    // Constructor
    public Ingredient(String ingredientName, String ingredientType, double quantity, String unit, boolean isAvailable) {
        this.ingredientName = ingredientName;
        this.ingredientType = ingredientType;
        this.quantity = quantity;
        this.unit = unit;
        this.isAvailable = isAvailable;
    }
    

    // Getters and setters
    public String getIngredientName() { return ingredientName; }
    public void setIngredientName(String ingredientName) { this.ingredientName = ingredientName; }

    public String getIngredientType() { return ingredientType; }
    public void setIngredientType(String ingredientType) { this.ingredientType = ingredientType; }

    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean isAvailable) { this.isAvailable = isAvailable; }

    // Check availability method
    public boolean checkAvailability() {
        return this.isAvailable;
    }

    @Override
    public String toString() {
        return quantity + " " + unit + " of " + ingredientName + " (" + ingredientType + ")";
    }
}