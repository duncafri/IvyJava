/* 
 Author: Ricky Duncan
SDEV200-11
10/06/2024
*/

package recipefinder;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DataLoader {

    public static ArrayList<Ingredient> loadIngredients(String filePath) {
        ArrayList<Ingredient> ingredients = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    ingredients.add(new Ingredient(parts[0], parts[1], Double.parseDouble(parts[2]), parts[3], Boolean.parseBoolean(parts[4])));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ingredients;
    }

    public static ArrayList<Recipe> loadRecipes(String filePath) {
        ArrayList<Recipe> recipes = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line using semicolons
                String[] parts = line.split(";");
                if (parts.length == 5) {
                    String recipeName = parts[0];
                    
                    // Parse the ingredients
                    String[] ingredientsArray = parts[1].split(",");
                    ArrayList<Ingredient> ingredients = new ArrayList<>();
                    for (String ing : ingredientsArray) {
                        ingredients.add(new Ingredient(ing.trim(), "", 0, "", true)); // Adjust the constructor as needed
                    }

                    // Parse steps and other fields
                    String[] stepsArray = parts[4].split(","); // Steps are now the 5th field
                    int preparationTime = Integer.parseInt(parts[2]); // Prep time is the 3rd field
                    boolean isFavorite = Boolean.parseBoolean(parts[3]); // Favorite status is the 4th field

                    recipes.add(new Recipe(recipeName, ingredients, stepsArray, preparationTime, isFavorite));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return recipes;
    }
}
