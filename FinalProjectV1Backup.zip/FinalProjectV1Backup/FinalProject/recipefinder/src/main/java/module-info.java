module recipefinder {
    requires javafx.controls;
    requires javafx.fxml;

    opens recipefinder to javafx.fxml;
    exports recipefinder;
}
